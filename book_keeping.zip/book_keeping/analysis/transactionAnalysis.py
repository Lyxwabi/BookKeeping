from transactions import *


class IncomeAnalysis:

    def __init__(self, book):
        self.book = book

    def show_trend(self):
        pass
